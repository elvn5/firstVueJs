<template>
  <div>
    <b-navbar fixed="top" toggleable="lg" type="dark" variant="info">
      <b-navbar-brand href="/">Главная страница</b-navbar-brand>

      <b-navbar-toggle target="nav-collapse"></b-navbar-toggle>

      <b-collapse id="nav-collapse" is-nav>
        <b-navbar-nav>
          <b-nav-item href="/orders">Заявки</b-nav-item>
        </b-navbar-nav>    
      </b-collapse>
    </b-navbar>
  </div>
</template>
